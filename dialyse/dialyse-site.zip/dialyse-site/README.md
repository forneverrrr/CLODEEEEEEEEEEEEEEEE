# Dialyse Øvebank – udgivelse på GitHub Pages

Statisk side uden server og uden byggetrin. Hele testen ligger i én fil: `index.html`
(2094 spørgsmål, 12 faste prøver à 25 spørgsmål).

## Sådan lægger du den på GitHub Pages

1. Opret et repository på GitHub (fx `dialyse`), eller brug dit eksisterende site-repo.
2. Upload filerne:
   - nyt repo: læg `index.html` og `.nojekyll` i roden;
   - eksisterende site: læg dem i en undermappe, fx `dialyse/index.html`.
3. Gå til *Settings → Pages*. Under *Build and deployment* vælg *Deploy from a branch*,
   branch `main`, mappe `/ (root)`, og tryk *Save*.
4. Efter 1-2 minutter åbner siden på:
   - nyt repo: `https://BRUGERNAVN.github.io/dialyse/`
   - undermappe: `https://BRUGERNAVN.github.io/REPO/dialyse/`
5. Eget domæne: *Settings → Pages → Custom domain*.

Fra kommandolinjen:

    git init && git add index.html .nojekyll && git commit -m "Dialyse Øvebank"
    git branch -M main
    git remote add origin https://github.com/BRUGERNAVN/dialyse.git
    git push -u origin main

## Noter
- Siden henter skrifttyper fra Google Fonts. Uden internet bruges systemskrift, og alt virker stadig.
- Fremgang og valg gemmes i browserens localStorage, pr. domæne og pr. enhed.
- Spørgsmålene er lavet ud fra lærebogen *Dialyse* (4. udgave, 2023). Bogen selv er ikke med.
  Siden er et øvelsesværktøj og ikke til klinisk beslutningstagning.

## Kildefiler (mappen `source/`)
- `q/` spørgsmål pr. emne (`s01.json` ... `s29.json`, nogle kapitler er delt i a/b/c)
- `template.html` siden, `build.py` samler data og side til `dialyse.html`,
  `make_zip.py` laver `index.html` og zip-filen
- Genbyg: `python3 build.py && python3 make_zip.py`
